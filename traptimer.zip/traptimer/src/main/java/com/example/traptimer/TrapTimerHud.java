package com.example.traptimer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.texture.OverlayTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ModelTransformationMode;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/**
 * Таймер в мире по центру пласта (стена 5x5) и трапки (куб 5x5x5):
 * иконка предмета + оставшееся время, как "4.4c".
 *
 * Работает для предметов, которые использовал ты сам.
 * Fabric 1.21.4 (yarn).
 */
public class TrapTimerHud implements ClientModInitializer {

    // ===================== НАСТРОЙКИ =====================

    // Предмет определяется по части названия (без учёта регистра).
    private static final String PLAST_NAME_KEY = "пласт";
    private static final String TRAP_NAME_KEY = "трапка";

    // Сколько секунд живёт пласт / трапка. Поставь реальные значения сервера.
    private static final float PLAST_SECONDS = 15.0f;
    private static final float TRAP_SECONDS = 15.0f;

    // Шаг обновления цифр (0.1 c).
    private static final float UPDATE_STEP_SECONDS = 0.1f;

    // true: таймер появляется, только если после использования реально пошёл кулдаун предмета
    // (защита от случаев, когда сервер не дал применить предмет).
    // Поставь false, если у предмета на сервере нет кулдауна.
    private static final boolean REQUIRE_COOLDOWN_CONFIRM = true;

    // Пласт: центр стены перед тобой. Расстояние вперёд и высота центра от блока, где стоят ноги.
    // Стена 5 высотой, низ на уровне ног -> центр (3-й блок) на 2.5.
    private static final double PLAST_DISTANCE = 3.0;
    private static final double PLAST_CENTER_Y = 2.5;

    // Трапка: центр куба вокруг тебя. Высота центра от блока, где стоят ноги.
    private static final double TRAP_CENTER_Y = 1.5;

    // Дальше этого расстояния таймер не рисуется.
    private static final double MAX_DISTANCE = 64.0;

    // Базовый размер надписи в мире и рост размера с расстоянием (чтобы читалось издалека).
    private static final float BASE_SCALE = 0.025f;
    private static final double SCALE_START_DISTANCE = 8.0;

    // =====================================================

    private enum Kind { PLAST, TRAP }

    private static final class Pending {
        final Kind kind;
        final ItemStack stack;
        final Vec3d center;
        int ticksLeft = 10;

        Pending(Kind kind, ItemStack stack, Vec3d center) {
            this.kind = kind;
            this.stack = stack;
            this.center = center;
        }
    }

    private static final class Active {
        final Kind kind;
        final ItemStack stack;
        final Vec3d center;
        final long endTick;

        Active(Kind kind, ItemStack stack, Vec3d center, long endTick) {
            this.kind = kind;
            this.stack = stack;
            this.center = center;
            this.endTick = endTick;
        }
    }

    private static final List<Pending> PENDING = new ArrayList<>();
    private static final List<Active> ACTIVE = new ArrayList<>();

    @Override
    public void onInitializeClient() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            onUse(player, world, hand);
            return ActionResult.PASS;
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            onUse(player, world, hand);
            return ActionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(TrapTimerHud::tick);
        WorldRenderEvents.AFTER_ENTITIES.register(TrapTimerHud::render);
    }

    private static Kind classify(ItemStack stack) {
        if (stack.isEmpty()) return null;
        String name = stack.getName().getString().toLowerCase(Locale.ROOT);
        if (name.contains(PLAST_NAME_KEY)) return Kind.PLAST;
        if (name.contains(TRAP_NAME_KEY)) return Kind.TRAP;
        return null;
    }

    private static Vec3d computeCenter(Kind kind, PlayerEntity player) {
        double baseX = Math.floor(player.getX()) + 0.5;
        double baseY = Math.floor(player.getY());
        double baseZ = Math.floor(player.getZ()) + 0.5;

        if (kind == Kind.TRAP) {
            return new Vec3d(baseX, baseY + TRAP_CENTER_Y, baseZ);
        }

        Direction facing = player.getHorizontalFacing();
        return new Vec3d(
                baseX + facing.getOffsetX() * PLAST_DISTANCE,
                baseY + PLAST_CENTER_Y,
                baseZ + facing.getOffsetZ() * PLAST_DISTANCE
        );
    }

    private static void onUse(PlayerEntity player, World world, Hand hand) {
        if (!world.isClient) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (player != client.player) return;

        ItemStack stack = player.getStackInHand(hand);
        Kind kind = classify(stack);
        if (kind == null) return;

        // Предмет на кулдауне: применение не пройдёт.
        if (player.getItemCooldownManager().isCoolingDown(stack)) return;

        // Защита от двойного срабатывания (событие по блоку + по предмету).
        for (Pending p : PENDING) {
            if (p.kind == kind && p.ticksLeft > 5) return;
        }
        long now = world.getTime();
        for (Active a : ACTIVE) {
            if (a.kind == kind && a.endTick - now > secondsFor(kind) * 20 - 10) return;
        }

        Pending pending = new Pending(kind, stack.copy(), computeCenter(kind, player));
        if (REQUIRE_COOLDOWN_CONFIRM) {
            PENDING.add(pending);
        } else {
            activate(pending, world);
        }
    }

    private static float secondsFor(Kind kind) {
        return kind == Kind.PLAST ? PLAST_SECONDS : TRAP_SECONDS;
    }

    private static void activate(Pending p, World world) {
        long end = world.getTime() + Math.round(secondsFor(p.kind) * 20f);
        ACTIVE.add(new Active(p.kind, p.stack, p.center, end));
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            PENDING.clear();
            ACTIVE.clear();
            return;
        }

        Iterator<Pending> it = PENDING.iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            if (client.player.getItemCooldownManager().isCoolingDown(p.stack)) {
                activate(p, client.world);
                it.remove();
            } else if (--p.ticksLeft <= 0) {
                it.remove();
            }
        }

        long now = client.world.getTime();
        ACTIVE.removeIf(a -> now >= a.endTick);
    }

    private static void render(WorldRenderContext ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || ACTIVE.isEmpty()) return;

        MatrixStack matrices = ctx.matrixStack();
        if (matrices == null) return;

        Camera camera = ctx.camera();
        Vec3d cam = camera.getPos();
        float tickDelta = ctx.tickCounter().getTickDelta(false);
        VertexConsumerProvider.Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
        TextRenderer font = client.textRenderer;

        for (Active a : ACTIVE) {
            double dist = a.center.distanceTo(cam);
            if (dist > MAX_DISTANCE) continue;

            float remaining = (a.endTick - (client.world.getTime() + tickDelta)) / 20f;
            if (remaining <= 0f) continue;

            float stepped = Math.round(remaining / UPDATE_STEP_SECONDS) * UPDATE_STEP_SECONDS;
            String text = String.format(Locale.US, "%.1fc", stepped);

            float scale = BASE_SCALE * (float) Math.max(1.0, dist / SCALE_START_DISTANCE);
            int iconPx = 16;
            int gap = 4;
            float total = iconPx + gap + font.getWidth(text);

            matrices.push();
            matrices.translate(a.center.x - cam.x, a.center.y - cam.y, a.center.z - cam.z);
            matrices.multiply(camera.getRotation());
            matrices.scale(scale, -scale, scale);

            // Текст справа от иконки, виден сквозь блоки.
            font.draw(
                    text,
                    -total / 2f + iconPx + gap,
                    -4f,
                    0xFFFFFFFF,
                    true,
                    matrices.peek().getPositionMatrix(),
                    consumers,
                    TextRenderer.TextLayerType.SEE_THROUGH,
                    0x55000000,
                    LightmapTextureManager.MAX_LIGHT_COORDINATE
            );

            // Иконка предмета слева.
            matrices.push();
            matrices.translate(-total / 2f + iconPx / 2f, 0f, 0f);
            matrices.scale(iconPx, -iconPx, iconPx);

            ItemRenderState state = new ItemRenderState();
            client.getItemModelManager().update(
                    state, a.stack, ModelTransformationMode.GUI, false, client.world, null, 0);
            state.render(matrices, consumers,
                    LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV);

            matrices.pop();
            matrices.pop();
        }

        consumers.draw();
    }
}
