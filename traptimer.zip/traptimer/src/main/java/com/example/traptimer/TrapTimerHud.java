package com.example.traptimer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/**
 * HUD-таймер кулдауна предмета (трапки) по центру экрана.
 * Fabric 1.21.4 (yarn).
 */
public class TrapTimerHud implements ClientModInitializer {

    // Предмет, чей кулдаун показываем. Замени на нужный.
    private static final Item TRAP_ITEM = Items.NETHERITE_SCRAP;

    // Полная длительность кулдауна в секундах (из неё считается остаток).
    private static final float TOTAL_COOLDOWN_SECONDS = 15.0f;

    // Шаг обновления цифр таймера в секундах (было 0.05, стало 0.1).
    private static final float UPDATE_STEP_SECONDS = 0.1f;

    // Смещение от центра экрана (0, 0 = ровно по центру).
    private static final int OFFSET_X = 0;
    private static final int OFFSET_Y = 20;

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register(TrapTimerHud::render);
    }

    private static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity player = client.player;
        if (player == null || client.options.hudHidden) return;

        ItemStack stack = new ItemStack(TRAP_ITEM);
        float progress = player.getItemCooldownManager()
                .getCooldownProgress(stack, tickCounter.getTickDelta(false));

        // 0 = кулдауна нет, ничего не рисуем
        if (progress <= 0f) return;

        float secondsLeft = progress * TOTAL_COOLDOWN_SECONDS;
        // Округляем до шага обновления (0.1 c)
        float stepped = Math.round(secondsLeft / UPDATE_STEP_SECONDS) * UPDATE_STEP_SECONDS;
        String text = String.format("%.1fc", stepped);

        TextRenderer font = client.textRenderer;
        int iconSize = 16;
        int gap = 4;
        int totalWidth = iconSize + gap + font.getWidth(text);

        int x = context.getScaledWindowWidth() / 2 - totalWidth / 2 + OFFSET_X;
        int y = context.getScaledWindowHeight() / 2 + OFFSET_Y;

        context.drawItem(stack, x, y);
        context.drawTextWithShadow(font, text, x + iconSize + gap, y + 4, 0xFFFFFFFF);
    }
}
