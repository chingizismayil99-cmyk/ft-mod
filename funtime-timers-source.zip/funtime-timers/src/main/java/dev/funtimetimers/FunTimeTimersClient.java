package dev.funtimetimers;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FunTimeTimersClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("funtime_timers");

    private static Config config;

    private static final class Timer {
        final String label;
        final long endMs;

        Timer(String label, long endMs) {
            this.label = label;
            this.endMs = endMs;
        }
    }

    private static final List<Timer> TIMERS = new ArrayList<>();
    private static long lastTrapkaMs = 0;
    private static long lastPlastMs = 0;

    /** Латинские буквы-двойники -> кириллица (на серверах часто пишут названия такими буквами). */
    private static String normalize(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toLowerCase(Locale.ROOT).toCharArray()) {
            switch (ch) {
                case 'a' -> sb.append('а');
                case 'e' -> sb.append('е');
                case 'o' -> sb.append('о');
                case 'p' -> sb.append('р');
                case 'c' -> sb.append('с');
                case 'x' -> sb.append('х');
                case 'y' -> sb.append('у');
                case 'k' -> sb.append('к');
                case 't' -> sb.append('т');
                case 'm' -> sb.append('м');
                case 'h' -> sb.append('н');
                case 'b' -> sb.append('в');
                case 'ё' -> sb.append('е');
                default -> sb.append(ch);
            }
        }
        return sb.toString();
    }

    private static boolean isNamed(ItemStack stack) {
        return stack.contains(DataComponentTypes.CUSTOM_NAME) || stack.contains(DataComponentTypes.ITEM_NAME);
    }

    private static boolean isTrapka(ItemStack stack) {
        String name = normalize(stack.getName().getString());
        if (name.contains(normalize(config.trapkaKeyword))) return true;
        String id = Registries.ITEM.getId(stack.getItem()).toString();
        return config.matchByItem && id.equals("minecraft:netherite_scrap") && isNamed(stack);
    }

    private static boolean isPlast(ItemStack stack) {
        String name = normalize(stack.getName().getString());
        if (name.contains(normalize(config.plastKeyword))) return true;
        String id = Registries.ITEM.getId(stack.getItem()).toString();
        return config.matchByItem && id.equals("minecraft:dried_kelp") && isNamed(stack);
    }

    private static void handleUse(ItemStack stack) {
        if (!config.enabled || stack.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (isTrapka(stack)) {
            if (now - lastTrapkaMs > 400) {
                lastTrapkaMs = now;
                start("Трапка", config.trapkaSeconds, now);
            }
        } else if (isPlast(stack)) {
            if (now - lastPlastMs > 400) {
                lastPlastMs = now;
                start("Пласт", config.plastSeconds, now);
            }
        }
    }

    @Override
    public void onInitializeClient() {
        config = Config.load();

        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.isClient()) handleUse(player.getStackInHand(hand));
            return ActionResult.PASS;
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient()) handleUse(player.getStackInHand(hand));
            return ActionResult.PASS;
        });

        HudRenderCallback.EVENT.register(FunTimeTimersClient::renderHud);

        // Команды: /ftt trapka <сек>, /ftt plast <сек>, /ftt clear, /ftt toggle, /ftt info, /ftt test
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("ftt")
                .then(ClientCommandManager.literal("trapka")
                    .then(ClientCommandManager.argument("sec", IntegerArgumentType.integer(1, 3600))
                        .executes(ctx -> {
                            config.trapkaSeconds = IntegerArgumentType.getInteger(ctx, "sec");
                            config.save();
                            ctx.getSource().sendFeedback(Text.literal("Трапка: " + config.trapkaSeconds + " с"));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("plast")
                    .then(ClientCommandManager.argument("sec", IntegerArgumentType.integer(1, 3600))
                        .executes(ctx -> {
                            config.plastSeconds = IntegerArgumentType.getInteger(ctx, "sec");
                            config.save();
                            ctx.getSource().sendFeedback(Text.literal("Пласт: " + config.plastSeconds + " с"));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("clear")
                    .executes(ctx -> {
                        synchronized (TIMERS) { TIMERS.clear(); }
                        ctx.getSource().sendFeedback(Text.literal("Таймеры сброшены"));
                        return 1;
                    }))
                .then(ClientCommandManager.literal("toggle")
                    .executes(ctx -> {
                        config.enabled = !config.enabled;
                        config.save();
                        ctx.getSource().sendFeedback(Text.literal("Мод " + (config.enabled ? "включён" : "выключен")));
                        return 1;
                    }))
                // Проверка, что мод вообще работает: запускает тестовый таймер на 10 секунд.
                .then(ClientCommandManager.literal("test")
                    .executes(ctx -> {
                        start("Тест", 10, System.currentTimeMillis());
                        ctx.getSource().sendFeedback(Text.literal("Тестовый таймер на 10 с запущен"));
                        return 1;
                    }))
                // Показывает, что мод видит в руке.
                .then(ClientCommandManager.literal("info")
                    .executes(ctx -> {
                        MinecraftClient mc = MinecraftClient.getInstance();
                        if (mc.player == null) return 0;
                        ItemStack s = mc.player.getMainHandStack();
                        String id = Registries.ITEM.getId(s.getItem()).toString();
                        ctx.getSource().sendFeedback(Text.literal(
                            "Предмет: " + id + " | имя: " + s.getName().getString()
                                + " | трапка=" + isTrapka(s) + " | пласт=" + isPlast(s)));
                        return 1;
                    }))));
    }

    private static void start(String label, int seconds, long now) {
        synchronized (TIMERS) {
            TIMERS.add(new Timer(label, now + seconds * 1000L));
        }
    }

    private static void renderHud(DrawContext ctx, net.minecraft.client.render.RenderTickCounter tickCounter) {
        if (!config.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        long now = System.currentTimeMillis();
        int y = config.hudY;
        synchronized (TIMERS) {
            TIMERS.removeIf(t -> t.endMs <= now);
            for (Timer t : TIMERS) {
                double left = (t.endMs - now) / 1000.0;
                int color = left <= 5 ? 0xFFFF5555 : 0xFFFFFFFF;
                String text = String.format(Locale.ROOT, "%s: %.1f с", t.label, left);
                ctx.drawTextWithShadow(mc.textRenderer, text, config.hudX, y, color);
                y += 11;
            }
        }
    }
}
