package dev.funtimetimers;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FunTimeTimersClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("funtime_timers");

    private static Config config;

    private static final class Timer {
        final String label;
        final long endMs;

        Timer(String label, long endMs) {
            this.label = label;
            this.endMs = endMs;
        }
    }

    private static final List<Timer> TIMERS = new ArrayList<>();
    private static long lastTrapkaMs = 0;
    private static long lastPlastMs = 0;

    @Override
    public void onInitializeClient() {
        config = Config.load();

        // Правый клик предметом: если в названии есть «трапка» или «пласт» — запускаем таймер.
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!world.isClient() || !config.enabled) return ActionResult.PASS;

            ItemStack stack = player.getStackInHand(hand);
            if (stack.isEmpty()) return ActionResult.PASS;

            String name = stack.getName().getString().toLowerCase(Locale.ROOT);
            long now = System.currentTimeMillis();

            if (name.contains(config.trapkaKeyword.toLowerCase(Locale.ROOT))) {
                if (now - lastTrapkaMs > 400) {
                    lastTrapkaMs = now;
                    start("Трапка", config.trapkaSeconds, now);
                }
            } else if (name.contains(config.plastKeyword.toLowerCase(Locale.ROOT))) {
                if (now - lastPlastMs > 400) {
                    lastPlastMs = now;
                    start("Пласт", config.plastSeconds, now);
                }
            }
            return ActionResult.PASS; // сами предмет не блокируем, сервер работает как обычно
        });

        HudRenderCallback.EVENT.register(FunTimeTimersClient::renderHud);

        // Команды: /ftt trapka <сек>, /ftt plast <сек>, /ftt clear, /ftt toggle
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("ftt")
                .then(ClientCommandManager.literal("trapka")
                    .then(ClientCommandManager.argument("sec", IntegerArgumentType.integer(1, 3600))
                        .executes(ctx -> {
                            config.trapkaSeconds = IntegerArgumentType.getInteger(ctx, "sec");
                            config.save();
                            ctx.getSource().sendFeedback(Text.literal("Трапка: " + config.trapkaSeconds + " с"));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("plast")
                    .then(ClientCommandManager.argument("sec", IntegerArgumentType.integer(1, 3600))
                        .executes(ctx -> {
                            config.plastSeconds = IntegerArgumentType.getInteger(ctx, "sec");
                            config.save();
                            ctx.getSource().sendFeedback(Text.literal("Пласт: " + config.plastSeconds + " с"));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("clear")
                    .executes(ctx -> {
                        synchronized (TIMERS) { TIMERS.clear(); }
                        ctx.getSource().sendFeedback(Text.literal("Таймеры сброшены"));
                        return 1;
                    }))
                .then(ClientCommandManager.literal("toggle")
                    .executes(ctx -> {
                        config.enabled = !config.enabled;
                        config.save();
                        ctx.getSource().sendFeedback(Text.literal("Мод " + (config.enabled ? "включён" : "выключен")));
                        return 1;
                    }))));
    }

    private static void start(String label, int seconds, long now) {
        synchronized (TIMERS) {
            TIMERS.add(new Timer(label, now + seconds * 1000L));
        }
    }

    private static void renderHud(DrawContext ctx, net.minecraft.client.render.RenderTickCounter tickCounter) {
        if (!config.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        long now = System.currentTimeMillis();
        int y = config.hudY;
        synchronized (TIMERS) {
            TIMERS.removeIf(t -> t.endMs <= now);
            for (Timer t : TIMERS) {
                double left = (t.endMs - now) / 1000.0;
                int color = left <= 5 ? 0xFFFF5555 : 0xFFFFFFFF;
                String text = String.format(Locale.ROOT, "%s: %.1f с", t.label, left);
                ctx.drawTextWithShadow(mc.textRenderer, text, config.hudX, y, color);
                y += 11;
            }
        }
    }
}
