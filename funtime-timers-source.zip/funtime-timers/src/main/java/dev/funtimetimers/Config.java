package dev.funtimetimers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Настройки мода. Файл: .minecraft/config/funtime-timers.json */
public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("funtime-timers.json");

    /** Сколько секунд действует трапка. Поставьте своё значение. */
    public int trapkaSeconds = 15;
    /** Сколько секунд действует пласт. Поставьте своё значение. */
    public int plastSeconds = 30;

    /** По какому слову в названии предмета определяем трапку / пласт (без учёта регистра). */
    public String trapkaKeyword = "трапка";
    public String plastKeyword = "пласт";

    /** Узнавать трапку/пласт ещё и по типу предмета (незеритовый обломок / сушёные водоросли с именем). */
    public boolean matchByItem = true;

    public int hudX = 6;
    public int hudY = 60;
    public boolean enabled = true;

    public static Config load() {
        if (Files.exists(PATH)) {
            try (Reader r = Files.newBufferedReader(PATH, StandardCharsets.UTF_8)) {
                Config c = GSON.fromJson(r, Config.class);
                if (c != null) return c;
            } catch (Exception e) {
                FunTimeTimersClient.LOGGER.warn("Не удалось прочитать конфиг, используются значения по умолчанию", e);
            }
        }
        Config c = new Config();
        c.save();
        return c;
    }

    public void save() {
        try (Writer w = Files.newBufferedWriter(PATH, StandardCharsets.UTF_8)) {
            GSON.toJson(this, w);
        } catch (IOException e) {
            FunTimeTimersClient.LOGGER.warn("Не удалось сохранить конфиг", e);
        }
    }
}
